async function register() {
    const username = document.getElementById('regUsername').value;
    const password = document.getElementById('regPassword').value;
    
    const response = await fetch('http://localhost:3000/register', {
    method: 'POST',
    headers: {
    'Content-Type': 'application/json',
    },
    body: JSON.stringify({ username, password }),
    });
    
    const result = await response.text();
    alert(result);
    }
    
    async function login() {
    const username = document.getElementById('loginUsername').value;
    const password = document.getElementById('loginPassword').value;
    
    const response = await fetch('http://localhost:8080/login', {
    method: 'POST',
    headers: {
    'Content-Type': 'application/json',
    },
    body: JSON.stringify({ username, password }),
    });
    
    const result = await response.json();
    if (response.status === 200) {
    alert(`Login successful!\nToken: ${result.token}`);
    } else {
    alert(result);
    }
    }
    
    