const express = require('express');
const bodyParser = require('body-parser');
const mssql = require('mssql');
const path = require('path');

const app = express();
const port = 3000;

app.use(express.static('public'));
app.use(bodyParser.urlencoded({ extended: true }));

// Конфигурация для подключения к базе данных с использованием аутентификации Windows
const dbConfig = {
  server: 'DESKTOP-MUDCOF5',
  database: 'SchoolTest',
  options: {
    trustedConnection: true, // Использование аутентификации Windows
    encrypt: true, // For Azure users
  },
};

// Роут для страницы входа
app.post('/window/login', async (req, res) => {
  const username = req.body.username;
  const password = req.body.password;

  try {
    // Подключение к базе данных
    const pool = await mssql.connect(dbConfig);

    // Запрос к базе данных для проверки авторизации
    const result = await pool.request()
      .input('username', mssql.NVarChar, username)
      .input('password', mssql.NVarChar, password)
      .query('SELECT * FROM Users WHERE Username = @username');

    // Проверка существования пользователя в базе данных
    if (result.recordset.length > 0) {
      // Здесь можно добавить логику проверки пароля.
      // Обратите внимание, что в реальном проекте рекомендуется использовать хэширование паролей и безопасные методы аутентификации.
      // Для простоты примера, здесь проверяется только существование пользователя.

      // Перенаправление на index.html после успешной аутентификации
      res.redirect('/index.html');
    } else {
      res.send('Неверный логин или пароль');
    }
  } catch (err) {
    console.error('Error authenticating user', err);
    res.status(500).send('Internal Server Error');
  }
});

// Роут для страницы log.html
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'log.html'));
});

// Запуск сервера
app.listen(port, () => {
  console.log(`Сервер запущен  http://localhost:${port}/window/login.html`);
});
