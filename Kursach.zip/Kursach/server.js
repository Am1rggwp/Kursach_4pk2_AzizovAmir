
const express = require('express');
const expressBodyParser = require('body-parser');
const app = express();
const port = 3000;


app.use(express.static('public'));
app.use('/window', express.static('window'));
app.use(expressBodyParser.urlencoded({ extended: true }));
// Роут для главной страницы
app.get('/', (req, res) => {
  res.render('index');
});

// Роут для страницы регистрации
app.get('/window/reg', (req, res) => {
  res.render('reg');
});

// Обработчик формы регистрации
app.post('/window/reg', (req, res) => {
  const username = req.body.username;
  const password = req.body.password;
  // Добавьте здесь логику сохранения пользователя в базе данных
  res.send(`Регистрация успешна, ${username}!`);
});

// Роут для страницы входа
app.get('/window/login', (req, res) => {
  res.render('login');
});

// Обработчик формы входа
app.post('/window/login', (req, res) => {
  const username = req.body.username;
  const password = req.body.password;
  
  if(username === "1" && password === "1" ){
    res.send(`Добро пожаловать, ${username}!`);
  }else
  res.send(`не добро пожаловать`);
});

// Запуск сервера
app.listen(port, () => {
  console.log(`Сервер запущен  http://localhost:${port}`);
});

